@echo off
setlocal
cd /d "%~dp0"
echo Actualizando Torrents a la version 0.4.0...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0actualizar.ps1"
if errorlevel 1 (
  echo.
  echo No se ha podido completar la actualizacion.
  pause
  exit /b 1
)
echo.
echo Actualizacion completada. Torrents se abrira ahora.
pause
exit /b 0
