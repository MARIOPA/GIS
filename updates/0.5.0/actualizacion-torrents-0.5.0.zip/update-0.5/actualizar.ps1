$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$folder = "torrents-portable-windows-x64-0.2.0"
$candidates = @()
$search = $root
for ($level = 0; $level -lt 6; $level++) {
  $candidates += Join-Path $search $folder
  $parent = Split-Path -Parent $search
  if (-not $parent -or $parent -eq $search) { break }
  $search = $parent
}
$app = $candidates | Where-Object { Test-Path (Join-Path $_ "Abrir-Torrents.cmd") } | Select-Object -First 1
if (-not $app) {
  throw "No se encuentra $folder. Ejecuta INSTALAR-Y-ABRIR-TORRENTS.cmd en la carpeta principal."
}

Get-CimInstance Win32_Process |
  Where-Object { $_.Name -eq "node.exe" -and $_.CommandLine -like "*$app*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }

$backup = Join-Path $app ".update-backup-before-0.5.0"
if (-not (Test-Path $backup)) {
  New-Item -ItemType Directory -Path $backup | Out-Null
  foreach ($name in @("dist", "server", "scripts", "package.json", "package-lock.json")) {
    $source = Join-Path $app $name
    if (Test-Path $source) { Copy-Item $source $backup -Recurse -Force }
  }
}

Copy-Item (Join-Path $root "payload\app\*") $app -Recurse -Force
$surfaceSource = Join-Path $root "payload\surface"
$surfaceDestination = Join-Path $app ".data\surfaces\pnoa-bal-462-4382-v3"
New-Item -ItemType Directory -Path $surfaceDestination -Force | Out-Null
Copy-Item (Join-Path $surfaceSource "*") $surfaceDestination -Recurse -Force

$records = Get-Content (Join-Path $surfaceDestination "checksums.json") -Raw | ConvertFrom-Json
foreach ($record in $records.PSObject.Properties) {
  $path = Join-Path $surfaceDestination $record.Name
  if (-not (Test-Path $path)) { throw "Falta un archivo de la superficie: $($record.Name)" }
  $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($hash -ne $record.Value.sha256) { throw "Archivo danado: $($record.Name)" }
}

Set-Content -LiteralPath (Join-Path $app ".data\surface-selection.json") -Value '{"id":"pnoa-bal-462-4382-v3"}' -Encoding ASCII
Start-Process -FilePath (Join-Path $app "Abrir-Torrents.cmd") -WorkingDirectory $app
