@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Get-ChildItem -LiteralPath . -Recurse -File | Unblock-File; & '.\actualizar.ps1'"
if errorlevel 1 (
  echo.
  echo No se ha podido actualizar Torrents. Conserva el mensaje mostrado arriba.
  pause
  exit /b 1
)
echo.
echo Torrents 0.6.0 se ha actualizado y se abrira ahora.
pause
