import { Router } from "express";
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { collectionSchema } from "./validation.mjs";
import { pythonExecutable } from "./paths.mjs";
const appRoot = resolve(fileURLToPath(new URL("..", import.meta.url)));
export function terrainCapability(directory) {
  if (
    !directory ||
    !existsSync(resolve(directory, "dtm.tif")) ||
    !existsSync(resolve(directory, "preview.json"))
  )
    return { status: "missing", message: "No hay un MDT preparado." };
  try {
    const surfaceFile = resolve(directory, "surface.json");
    const version = existsSync(surfaceFile)
      ? "?surface=" +
        encodeURIComponent(JSON.parse(readFileSync(surfaceFile, "utf8")).id)
      : "";
    return {
      ...JSON.parse(readFileSync(resolve(directory, "preview.json"), "utf8")),
      preview: "/api/terrain/preview.png",
      ...(existsSync(resolve(directory, "tiles.json"))
        ? {
            raster: {
              ...JSON.parse(
                readFileSync(resolve(directory, "tiles.json"), "utf8"),
              ),
              tiles: ["/api/terrain/tiles/{z}/{x}/{y}.png" + version],
            },
          }
        : {}),
      ...(existsSync(resolve(directory, "hillshade.json"))
        ? {
            hillshade: {
              ...JSON.parse(
                readFileSync(resolve(directory, "hillshade.json"), "utf8"),
              ),
              tiles: [
                "/api/terrain/hillshade/{z}/{x}/{y}.png" + version,
              ],
            },
          }
        : {}),
      ...(existsSync(resolve(directory, "contours.geojson"))
        ? {
            contours: {
              url: "/api/terrain/contours.geojson" + version,
              intervals: existsSync(resolve(directory, "fine-contours.json"))
                ? [0.25, 5, 10, 20]
                : [5, 10, 20],
              ...(existsSync(resolve(directory, "fine-contours.json"))
                ? {
                    fine: {
                      ...JSON.parse(
                        readFileSync(
                          resolve(directory, "fine-contours.json"),
                          "utf8",
                        ),
                      ),
                      tiles: [
                        "/api/terrain/fine-contours/{z}/{x}/{y}.png" +
                          version,
                      ],
                    },
                  }
                : {}),
            },
          }
        : {}),
      ...(existsSync(resolve(directory, "hydrology.json"))
        ? {
            hydrology: {
              ...JSON.parse(
                readFileSync(resolve(directory, "hydrology.json"), "utf8"),
              ),
              depressions: {
                ...JSON.parse(
                  readFileSync(resolve(directory, "tiles.json"), "utf8"),
                ),
                tiles: [
                  "/api/terrain/depressions/{z}/{x}/{y}.png" + version,
                ],
              },
              accumulation: {
                ...JSON.parse(
                  readFileSync(resolve(directory, "tiles.json"), "utf8"),
                ),
                tiles: [
                  "/api/terrain/accumulation/{z}/{x}/{y}.png" + version,
                ],
              },
              network: {
                url: "/api/terrain/flow-network.geojson" + version,
              },
            },
          }
        : {}),
      message:
        "MDT provisional. Datum vertical y precisión pendientes de validar.",
    };
  } catch {
    return {
      status: "missing",
      message: "No se ha podido leer la preparación del terreno.",
    };
  }
}
export function terrainRouter(directory) {
  const router = Router();
  let running = 0;
  router.get("/tiles/:z/:x/:y.png", (req, res) => {
    const parts = [req.params.z, req.params.x, req.params.y];
    if (!parts.every((p) => /^(0|[1-9]\d{0,6})$/.test(p)))
      return res.status(400).end();
    const [z, x, y] = parts.map(Number);
    if (z > 20 || x >= 2 ** z || y >= 2 ** z) return res.status(400).end();
    const file =
      directory &&
      resolve(directory, "tiles", String(z), String(x), `${y}.png`);
    if (!file || !existsSync(file)) return res.status(204).end();
    // Cache in the browser privately; surface changes require restarting the local server.
    res.set("Cache-Control", "private, max-age=3600");
    res.sendFile(file, { dotfiles: "allow" });
  });
  router.get("/hillshade/:z/:x/:y.png", (req, res) => {
    const parts = [req.params.z, req.params.x, req.params.y];
    if (!parts.every((p) => /^(0|[1-9]\d{0,6})$/.test(p)))
      return res.status(400).end();
    const [z, x, y] = parts.map(Number);
    if (z > 20 || x >= 2 ** z || y >= 2 ** z) return res.status(400).end();
    const file =
      directory &&
      resolve(directory, "hillshade", String(z), String(x), `${y}.png`);
    if (!file || !existsSync(file)) return res.status(204).end();
    res.set("Cache-Control", "private, max-age=3600");
    res.sendFile(file, { dotfiles: "allow" });
  });
  for (const folder of ["fine-contours", "depressions", "accumulation"])
    router.get(`/${folder}/:z/:x/:y.png`, (req, res) => {
      const parts = [req.params.z, req.params.x, req.params.y];
      if (!parts.every((p) => /^(0|[1-9]\d{0,6})$/.test(p)))
        return res.status(400).end();
      const [z, x, y] = parts.map(Number);
      if (z > 20 || x >= 2 ** z || y >= 2 ** z)
        return res.status(400).end();
      const file =
        directory &&
        resolve(directory, folder, String(z), String(x), `${y}.png`);
      if (!file || !existsSync(file)) return res.status(204).end();
      res.set("Cache-Control", "private, max-age=3600");
      res.sendFile(file, { dotfiles: "allow" });
    });
  router.get("/contours.geojson", (_, res) => {
    const file = directory && resolve(directory, "contours.geojson");
    if (!file || !existsSync(file)) return res.status(404).end();
    res.set("Cache-Control", "private, max-age=3600");
    res.type("application/geo+json").sendFile(file, { dotfiles: "allow" });
  });
  router.get("/flow-network.geojson", (_, res) => {
    const file = directory && resolve(directory, "flow-network.geojson");
    if (!file || !existsSync(file)) return res.status(404).end();
    res.set("Cache-Control", "private, max-age=3600");
    res.type("application/geo+json").sendFile(file, { dotfiles: "allow" });
  });
  router.get("/preview.png", (_, res) => {
    if (terrainCapability(directory).status === "missing")
      return res.status(404).end();
    res.sendFile(resolve(directory, "preview.png"), { dotfiles: "allow" });
  });
  async function query(req, res, kind) {
    if (terrainCapability(directory).status === "missing")
      return res.status(409).json({ error: "No hay un MDT preparado." });
    const input = { kind };
    if (kind === "point" || kind === "watershed") {
      if (
        !Number.isFinite(req.body?.lng) ||
        !Number.isFinite(req.body?.lat) ||
        Math.abs(req.body.lng) > 180 ||
        Math.abs(req.body.lat) > 90
      )
        return res.status(400).json({ error: "Coordenadas WGS84 inválidas." });
      input.lng = req.body.lng;
      input.lat = req.body.lat;
    } else if (kind === "profile") {
      const parsed = collectionSchema.safeParse({
        type: "FeatureCollection",
        features: [
          { type: "Feature", geometry: req.body?.geometry, properties: {} },
        ],
      });
      if (
        !parsed.success ||
        parsed.data.features[0].geometry.type !== "LineString" ||
        parsed.data.features[0].geometry.coordinates.length > 1000
      )
        return res
          .status(400)
          .json({ error: "Usa una línea WGS84 de hasta 1.000 vértices." });
      input.coordinates = parsed.data.features[0].geometry.coordinates;
    } else {
      if (
        !Number.isFinite(req.body?.rainfall_mm) ||
        req.body.rainfall_mm < 0 ||
        req.body.rainfall_mm > 500 ||
        !Number.isFinite(req.body?.minimum_depth_m) ||
        req.body.minimum_depth_m < 0 ||
        req.body.minimum_depth_m > 2
      )
        return res.status(400).json({
          error: "Usa una lluvia de 0 a 500 mm y una profundidad de 0 a 2 m.",
        });
      input.rainfall_mm = req.body.rainfall_mm;
      input.minimum_depth_m = req.body.minimum_depth_m;
    }
    if (running >= 2)
      return res.status(429).json({
        error: "Hay otras consultas de terreno en curso. Vuelve a intentarlo.",
      });
    running++;
    const hydrologyQuery = kind === "watershed" || kind === "flood";
    const child = spawn(
      pythonExecutable(),
      [
        resolve(
          appRoot,
          hydrologyQuery
            ? "scripts/query_hydrology.py"
            : "scripts/query_terrain.py",
        ),
        resolve(directory),
      ],
      { stdio: ["pipe", "pipe", "pipe"] },
    );
    const timer = setTimeout(
      () => child.kill("SIGTERM"),
      kind === "flood" ? 30000 : 15000,
    );
    let output = "";
    let failed = false;
    child.stdin.on("error", () => {});
    child.stdin.end(JSON.stringify(input));
    child.stdout.on("data", (b) => {
      output += b.toString();
      if (output.length > (kind === "flood" ? 8000000 : 2000000)) {
        failed = true;
        child.kill("SIGTERM");
      }
    });
    child.stderr.on("data", () => {});
    let completed = false;
    const finish = (code) => {
      if (completed) return;
      completed = true;
      clearTimeout(timer);
      running--;
      if (res.destroyed) return;
      if (code !== 0 || failed)
        return res.status(422).json({
          error:
            kind === "watershed"
              ? "No se ha podido delimitar la cuenca. Elige un punto dentro del MDT preparado."
              : kind === "flood"
                ? "No se ha podido calcular el mapa estático para este episodio."
                : "No se ha podido muestrear el terreno. Revisa la cobertura, la longitud de la línea y el entorno Python.",
        });
      try {
        res.json(JSON.parse(output));
      } catch {
        res.status(500).json({ error: "Respuesta del terreno inválida." });
      }
    };
    child.on("error", () => finish(1));
    child.on("close", finish);
  }
  router.post("/elevation", (req, res) => query(req, res, "point"));
  router.post("/profile", (req, res) => query(req, res, "profile"));
  router.post("/watershed", (req, res) => query(req, res, "watershed"));
  router.post("/flash-flood", (req, res) => query(req, res, "flood"));
  return router;
}
